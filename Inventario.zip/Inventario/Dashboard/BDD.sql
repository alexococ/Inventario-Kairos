CREATE TABLE PRODUCTO{
    id_Referencia INT AUTO INCREMENT NOT NULL,
    Tipologia VARCHAR(20) NOT NULL,
    Nombre_Objeto VARCHAR(50) NOT NULL,
    Descripcion TEXT,
    Fecha_Compra DATE NOT NULL,
    Fecha_Seguro DATE,
    Ubicacion VARCHAR(50) NOT NULL,
    Responsable VARCHAR(50) NOT NULL,
    Fecha_Baja DATE,
    Observaciones TEXT,
    Amortizacion BOOLEAN,
    id_Contable INT,
};

CREATE TABLE USUARIOS{
    id_Usuario INT AUTO INCREMENT NOT NULL,
    Nombre_Usuario VARCHAR(50) NOT NULL,
    Email VARCHAR(50) NOT NULL,
    Contraseña VARCHAR(50) NOT NULL
};