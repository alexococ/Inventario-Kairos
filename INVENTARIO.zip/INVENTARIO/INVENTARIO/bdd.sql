/*CREATE DATABASE Inventario;

USE Inventario;*/

CREATE TABLE Usuarios (
    idUsuario INT AUTO_INCREMENT PRIMARY KEY,
    CorreoUsuario VARCHAR(255) NOT NULL,
    ContraseñaUsuario VARCHAR(255) NOT NULL
);

CREATE TABLE Productos (
    idProducto INT AUTO_INCREMENT PRIMARY KEY,
    Tipologia VARCHAR(255) NOT NULL,
    Subtipologia VARCHAR(255) NOT NULL,
    Nombre VARCHAR(255) NOT NULL,
    Descripcion TEXT,
    Ubicacion VARCHAR(255) NOT NULL,
    Precio DECIMAL(10, 2) NOT NULL,
    FechaCompra DATE NOT NULL,
    Baja BOOLEAN NOT NULL,
    FechaBaja DATE,
    Seguro BOOLEAN NOT NULL,
    FechaSeguro DATE,
    Amortizacion DECIMAL(10, 2),
    idContable INT,
    Observaciones TEXT
);


INSERT INTO Usuarios (CorreoUsuario, ContraseñaUsuario) 
VALUES ('gcentro@kairos.coop', 'gcentro2024.');

-- Añadir el segundo usuario
INSERT INTO Usuarios (CorreoUsuario, ContraseñaUsuario) 
VALUES ('rmarset@kairos.coop', 'rmarset2024.');