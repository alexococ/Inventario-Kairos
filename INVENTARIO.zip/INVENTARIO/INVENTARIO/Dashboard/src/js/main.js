document.addEventListener("DOMContentLoaded", function() {
    var filtersButton = document.getElementById("dropdown");
    var filtersDropdown = document.getElementById("filtroDropdown");
    var tipologiaLink = document.getElementById("tipologia");
    var SubtipologiaLink = document.getElementById("Subtipologia");
    var BajaLink = document.getElementById("Baja")
    var SeguroLink = document.getElementById("Seguro")
    var ResponsableLink = document.getElementById("Responsable")
    
    
    var tipologiaInput = document.createElement("input");
    tipologiaInput.setAttribute("type", "text");
    tipologiaInput.style.display = "none";
    var isTipologiaInputVisible = false;


    var SubtipologiaInput = document.createElement("input");
    SubtipologiaInput.setAttribute("type", "text");
    SubtipologiaInput.style.display="none";
    var isSubtipologiaInputVisible = false;


    var BajaInput = document.createElement("input");
    BajaInput.setAttribute("type","text");
    BajaInput.style.display="none";
    var isBajaInputVisible = false;


    var SeguroInput = document.createElement("input");
    SeguroInput.setAttribute("type","text");
    SeguroInput.style.display="none";
    var isSeguroInputVisible = false;


    var ResponsableInput = document.createElement("input");
    ResponsableInput.setAttribute("type","text");
    ResponsableInput.style.display="none";
    var isResponsableInputVisible = false;




    // Ocultar el listado de filtros al cargar la página
    filtersDropdown.style.display = "none";

    // Agregar evento de clic al botón de filtros
    filtersButton.addEventListener("click", function(event) {
        event.stopPropagation();
        
        // Mostrar u ocultar el listado de filtros al hacer clic en el botón de filtros
        if (filtersDropdown.style.display === "none") {
            filtersDropdown.style.display = "block";
        } else {
            filtersDropdown.style.display = "none";
        }
    });


        //TIPOLOGIA



    // Mostrar u ocultar el campo de texto al hacer clic en "Tipologia"
    tipologiaLink.addEventListener("click", function(event) {
        event.preventDefault();
        event.stopPropagation();
        
        if (!isTipologiaInputVisible) {
            tipologiaInput.style.display = "block";
            isTipologiaInputVisible = true;
        } else {
            tipologiaInput.style.display = "none";
            isTipologiaInputVisible = false;
        }
    });

    // Detener la propagación del clic en el campo de texto
    tipologiaInput.addEventListener("click", function(event) {
        event.stopPropagation();
    });

    // Ocultar el campo de texto al hacer clic en cualquier parte del cuerpo de la página
    document.body.addEventListener("click", function() {
        filtersDropdown.style.display = "none";
        tipologiaInput.style.display = "none";
        isTipologiaInputVisible = false;
    });

    // Agregar el campo de texto al menú desplegable
    tipologiaLink.appendChild(tipologiaInput);

    



    // SUBTIPOLOGIA



    // Mostrar u ocultar el campo de texto al hacer clic en "Subtipologia"
    SubtipologiaLink.addEventListener("click", function(event) {
        event.preventDefault();
        event.stopPropagation();
        
        if (!isSubtipologiaInputVisible) {
            SubtipologiaInput.style.display = "block";
            isSubtipologiaInputVisible = true;
        } else {
            SubtipologiaInput.style.display = "none";
            isSubtipologiaInputVisible = false;
        }
    });

    // Detener la propagación del clic en el campo de texto
    SubtipologiaInput.addEventListener("click", function(event) {
        event.stopPropagation();
    });

    // Ocultar el campo de texto al hacer clic en cualquier parte del cuerpo de la página
    document.body.addEventListener("click", function() {
        filtersDropdown.style.display = "none";
        SubtipologiaInput.style.display = "none";
        isSubtipologiaInputVisible = false;
    });

    // Agregar el campo de texto al menú desplegable
    SubtipologiaLink.appendChild(SubtipologiaInput);




    //BAJA

    
    // Mostrar u ocultar el campo de texto al hacer clic en "Baja"
    BajaLink.addEventListener("click", function(event) {
        event.preventDefault();
        event.stopPropagation();
        
        if (!isBajaInputVisible) {
            BajaInput.style.display = "block";
            isBajaInputVisible = true;
        } else {
            BajaInput.style.display = "none";
            isBajaInputVisible = false;
        }
    });

    // Detener la propagación del clic en el campo de texto
    BajaInput.addEventListener("click", function(event) {
        event.stopPropagation();
    });

    // Ocultar el campo de texto al hacer clic en cualquier parte del cuerpo de la página
    document.body.addEventListener("click", function() {
        filtersDropdown.style.display = "none";
        BajaInput.style.display = "none";
        isBajaInputVisible = false;
    });

    // Agregar el campo de texto al menú desplegable
    BajaLink.appendChild(BajaInput);



        //SEGURO

    
    // Mostrar u ocultar el campo de texto al hacer clic en "Seguro"
    SeguroLink.addEventListener("click", function(event) {
        event.preventDefault();
        event.stopPropagation();
        
        if (!isSeguroInputVisible) {
            SeguroInput.style.display = "block";
            isSeguroInputVisible = true;
        } else {
            SeguroInput.style.display = "none";
            isSeguroInputVisible = false;
        }
    });

    // Detener la propagación del clic en el campo de texto
    SeguroInput.addEventListener("click", function(event) {
        event.stopPropagation();
    });

    // Ocultar el campo de texto al hacer clic en cualquier parte del cuerpo de la página
    document.body.addEventListener("click", function() {
        filtersDropdown.style.display = "none";
        SeguroInput.style.display = "none";
        isSeguroInputVisible = false;
    });

    // Agregar el campo de texto al menú desplegable
    SeguroLink.appendChild(SeguroInput);



            //RESPONSABLE

    
    // Mostrar u ocultar el campo de texto al hacer clic en "Responsable"
    ResponsableLink.addEventListener("click", function(event) {
        event.preventDefault();
        event.stopPropagation();
        
        if (!isResponsableInputVisible) {
            ResponsableInput.style.display = "block";
            isResponsableInputVisible = true;
        } else {
            ResponsableInput.style.display = "none";
            isResponsableInputVisible = false;
        }
    });

    // Detener la propagación del clic en el campo de texto
    ResponsableInput.addEventListener("click", function(event) {
        event.stopPropagation();
    });

    // Ocultar el campo de texto al hacer clic en cualquier parte del cuerpo de la página
    document.body.addEventListener("click", function() {
        filtersDropdown.style.display = "none";
        ResponsableInput.style.display = "none";
        isResponsableInputVisible = false;
    });

    // Agregar el campo de texto al menú desplegable
    ResponsableLink.appendChild(ResponsableInput);







    
    
    

});







