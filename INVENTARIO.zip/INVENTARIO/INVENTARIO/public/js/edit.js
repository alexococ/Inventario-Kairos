document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');

    const editProductForm = document.getElementById('edit-product-form');

    editProductForm.addEventListener('submit', async function(event) {
        event.preventDefault();

        const formData = new FormData(this);

        const editedProduct = {};

        formData.forEach((value, key) => {
            editedProduct[key] = value;
        });

        try {
            const response = await fetch(`/public/Edit/${productId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(editedProduct)
            });

            if (response.ok) {
                alert('Producto editado exitosamente');
                window.location.href = './Dashboard.html'; // Redireccionar al dashboard después de editar
            } else {
                alert('Error al editar el producto');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error al editar el producto');
        }
    });
});
