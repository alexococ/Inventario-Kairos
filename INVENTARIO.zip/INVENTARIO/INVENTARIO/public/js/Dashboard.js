// Agrega un evento click al botón "Aplicar Filtros"
document.getElementById('aplicarFiltros').addEventListener('click', async () => {
    // Obtén los valores de los filtros
    const tipologia = document.getElementById('tipologia').value;
    const subtipologia = document.getElementById('subtipologia').value;
    const ubicacion = document.getElementById('ubicacion').value;
    const baja = document.getElementById('baja').value;
    const fechaBaja = document.getElementById('fechaBaja').value;
    const seguro = document.getElementById('seguro').value;
    const fechaSeguro = document.getElementById('fechaSeguro').value;
    const precioDesde = document.getElementById('precioDesde').value;
    const precioHasta = document.getElementById('precioHasta').value;
    // Agrega más variables para los otros filtros...

    // Construye el objeto de filtros
    const filters = {
        Tipologia: tipologia,
        Subtipologia: subtipologia,
        Ubicacion: ubicacion,
        Baja: baja,
        FechaBaja : fechaBaja,
        Seguro: seguro,
        FechaSeguro: fechaSeguro,
        Precio: { $gte: precioDesde, $lte: precioHasta }
    };

    // Realiza una solicitud POST al servidor con los filtros
    const response = await fetch('/public/filter', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(filters)
    });

    // Verifica si la solicitud fue exitosa
    if (response.ok) {
        // Obtiene los productos filtrados
        const productos = await response.json();
        // Limpia la tabla de productos
        document.querySelector('#product-table tbody').innerHTML = '';
        // Agrega los productos filtrados a la tabla
        productos.forEach(producto => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${producto.Tipologia}</td>
                <td>${producto.Subtipologia}</td>
                <td>${producto.Nombre}</td>
                <td>${producto.Descripcion}</td>
                <td>${producto.Ubicacion}</td>
                <td>${producto.Precio}</td>
                <td>${producto.FechaCompra}</td>
                <td>${producto.Baja}</td>
                <td>${producto.FechaBaja}</td>
                <td>${producto.Seguro}</td>
                <td>${producto.FechaSeguro}</td>
                <td>${producto.Amortizacion}</td>
                <td>${producto.idContable}</td>
                <td>${producto.Observaciones}</td>
            `;
            document.querySelector('#product-table tbody').appendChild(row);
        });
    } else {
        // Si la solicitud falla, muestra un mensaje de error
        console.error('Error al obtener los productos filtrados');
    }
});

document.addEventListener('DOMContentLoaded', async function() {
    try {
        // Realizar una solicitud GET al servidor para obtener los productos
        const response = await fetch('/public/Dashboard');
        const productos = await response.json();

        // Obtener la tabla de productos
        const productTableBody = document.querySelector('#product-table tbody');

        // Limpiar la tabla de productos
        productTableBody.innerHTML = '';

        // Llenar la tabla con los productos recibidos
        productos.forEach(producto => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${producto.Tipologia}</td>
                <td>${producto.Subtipologia}</td>
                <td>${producto.Nombre}</td>
                <td>${producto.Descripcion}</td>
                <td>${producto.Ubicacion}</td>
                <td>${producto.FechaCompra}</td>
                <td>${producto.Seguro}</td>
                <td>${producto.FechaSeguro}</td>
                <td>${producto.Baja}</td>
                <td>${producto.FechaBaja}</td>
                <td>${producto.Responsable}</td>
                <td>${producto.Observaciones}</td>
                <td><button class="edit-btn" data-id="${producto._id}">Editar</button></td>
            `;
            productTableBody.appendChild(row);
        });

        // Agregar listeners para los botones de editar
        const editButtons = document.querySelectorAll('.edit-btn');
        editButtons.forEach(btn => {
            btn.addEventListener('click', async function() {
                const productId = this.getAttribute('data-id');
                window.location.href = `./Edit.html?id=${productId}`;
            });
        });
    } catch (error) {
        console.error('Error:', error);
        alert('Error al cargar el dashboard');
    }
});
