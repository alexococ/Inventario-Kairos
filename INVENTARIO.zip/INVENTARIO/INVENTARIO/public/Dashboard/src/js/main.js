document.addEventListener('DOMContentLoaded', function () {
    const productTableBody = document.querySelector('#product-table tbody');

    fetch('/public/Dashboard') // Esto debe ser la ruta correcta para obtener los productos desde tu servidor
        .then(response => response.json())
        .then(products => {
            products.forEach(product => {
                const row = `
                    <tr>
                        <td>${product.Tipologia}</td>
                        <td>${product.Subtipologia}</td>
                        <td>${product.Nombre}</td>
                        <td>${product.Descripcion}</td>
                        <td>${product.Ubicacion}</td>
                        <td>${product.FechaCompra}</td>
                        <td>${product.Seguro}</td>
                        <td>${product.FechaSeguro}</td>
                        <td>${product.Baja}</td>
                        <td>${product.FechaBaja}</td>
                        <td>${product.Responsable}</td>
                        <td>${product.Observaciones}</td>
                    </tr>
                `;
                productTableBody.insertAdjacentHTML('beforeend', row);
            });
        })
        .catch(error => console.error('Error al obtener los productos:', error));
});
