document.addEventListener('DOMContentLoaded', function () {
    const productTableBody = document.querySelector('#product-table tbody');

    // Evento de clic para el filtro por Tipología
    document.getElementById('Tipologia').addEventListener('click', function () {
        filtrarProductos('Tipologia');
    });

    // Evento de clic para el filtro por Subtipología
    document.getElementById('Subtipologia').addEventListener('click', function () {
        filtrarProductos('Subtipologia');
    });
    // Evento de clic para el filtro por Ubicacion
    document.getElementById('Ubicacion').addEventListener('click', function () {
        filtrarProductos('Ubicacion');
    });
    // Evento de clic para el filtro por Baja
    document.getElementById('Baja').addEventListener('click', function () {
        filtrarProductos('Baja');
    });
    // Evento de clic para el filtro por Fecha de Baja
    document.getElementById('Fecha_Baja').addEventListener('click', function () {
        filtrarProductos('Fecha_Baja');
    });
    // Evento de clic para el filtro por Seguro
    document.getElementById('Seguro').addEventListener('click', function () {
        filtrarProductos('Seguro');
    });
    // Evento de clic para el filtro por Fecha de Seguro
    document.getElementById('Fecha_Seguro').addEventListener('click', function () {
        filtrarProductos('Fecha_Seguro');
    });
    // Evento de clic para el filtro por Fecha de Compra
    document.getElementById('Fecha_Compra').addEventListener('click', function () {
        filtrarProductos('Fecha_Compra');
    });
    // Evento de clic para el filtro por Responsable
    document.getElementById('Responsable').addEventListener('click', function () {
        filtrarProductos('Responsable');
    });
    // Evento de clic para el filtro por Precio
    document.getElementById('Precio').addEventListener('click', function () {
        filtrarProductos('Precio');
    });



    // Otros eventos de clic para los demás filtros...

    // Función para filtrar los productos
    function filtrarProductos(campo) {
        const filtro = prompt(`Introduce el valor para filtrar por ${campo}:`);
        const rows = document.querySelectorAll('#product-table tbody tr');

        rows.forEach(row => {
            const td = row.querySelector(`td[data-field="${campo}"]`);
            if (td) {
                if (td.textContent.toLowerCase().includes(filtro.toLowerCase())) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    }




    fetch('/public/Dashboard') // Esto debe ser la ruta correcta para obtener los productos desde tu servidor
        .then(response => response.json())
        .then(products => {
            products.forEach(product => {
                const row = `
                    <tr>
                        <td>${product.Tipologia}</td>
                        <td>${product.Subtipologia}</td>
                        <td>${product.Nombre}</td>
                        <td>${product.Descripcion}</td>
                        <td>${product.Ubicacion}</td>
                        <td>${product.FechaCompra}</td>
                        <td>${product.Seguro}</td>
                        <td>${product.FechaSeguro}</td>
                        <td>${product.Baja}</td>
                        <td>${product.FechaBaja}</td>
                        <td>${product.Responsable}</td>
                        <td>${product.Observaciones}</td>
                    </tr>
                `;
                productTableBody.insertAdjacentHTML('beforeend', row);
            });
        })
        .catch(error => console.error('Error al obtener los productos:', error));
});
