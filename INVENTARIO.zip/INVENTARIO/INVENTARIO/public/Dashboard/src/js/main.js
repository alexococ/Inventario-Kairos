document.addEventListener("DOMContentLoaded", function() {
    // Obtener el elemento donde se mostrarán los productos
    var productList = document.getElementById("product-list");

    // Obtener los productos desde el servidor y mostrarlos en el dashboard
    fetch('/products')
        .then(response => response.json())
        .then(products => {
            // Limpiar la lista de productos antes de agregar los nuevos
            productList.innerHTML = '';

            // Recorrer los productos y agregar cada uno a la lista
            products.forEach(product => {
                // Crear un elemento de lista para cada producto
                var listItem = document.createElement('li');

                // Construir el HTML del producto
                listItem.innerHTML = `
                    <strong>${product.nombre}</strong>: ${product.descripcion}, Precio: ${product.precio}
                `;

                // Agregar el producto a la lista
                productList.appendChild(listItem);
            });
        })
        .catch(error => {
            console.error('Error al obtener los productos:', error);
            // Mostrar un mensaje de error en caso de fallo al obtener los productos
            productList.innerHTML = '<li>Error al obtener los productos. Por favor, intenta de nuevo más tarde.</li>';
        });
});
