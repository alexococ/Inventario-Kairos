const express = require('express');
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));

const url = 'mongodb://localhost:27017';
const dbName = 'inventario';
const usersCollection = 'usuarios';

app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(usersCollection);

        const user = await collection.findOne({ username, password });

        if (user) {
            res.send('Inicio de sesión exitoso');
        } else {
            res.status(401).send('Credenciales incorrectas');
        }
    } catch (error) {
        console.error('Error de inicio de sesión:', error);
        res.status(500).send('Error de servidor');
    } finally {
        await client.close();
    }
});

app.listen(port, () => {
    console.log(`Servidor de inicio de sesión en http://localhost:${port}`);
});
