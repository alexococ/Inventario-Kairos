const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const { Double, Decimal128 } = require('mongodb');

const app = express();

app.use(bodyParser.json());


// Conexión a la base de datos MongoDB
mongoose.connect('mongodb://localhost:27017/inventario')
    .then(() => console.log('Conexión a MongoDB establecida'))
    .catch(err => console.error('Error al conectar a MongoDB:', err));


// Servir archivos estáticos desde la carpeta 'public'
app.use(express.static(path.join(__dirname, 'public')));


// Ruta para cargar la página de inicio de sesión
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public','Login.html'));
});





// Definir los esquemas de tus colecciones (usuarios y productos)
const usuarioSchema = new mongoose.Schema({
    correoUsuario: String,
    ContraseñaUsuario: String
});

const productoSchema = new mongoose.Schema({
Tipologia: String,
Subtipologia: String,
Nombre: String,
Descripcion: String,
Ubicacion: String,
Precio: Number,
FechaCompra: Date,
Baja: String,   
FechaBaja: Date,
Seguro: String,
FechaSeguro: Date,
Amortizacion: Number,
idContable: Number,
Observaciones: String
});

// Definir modelos basados en los esquemas
const Usuario = mongoose.model('Usuario', usuarioSchema);
const Producto = mongoose.model('Producto', productoSchema);



// Configurar middlewares
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());




// Rutas de tu aplicación
// Ruta para el login
app.post('/login', async (req, res) => {
    const { correoUsuario, ContraseñaUsuario } = req.body;
  
    try {
      // Busca al usuario en la base de datos
      const usuario = await Usuario.findOne({ correoUsuario, ContraseñaUsuario });
  
      // Si el usuario no existe o la contraseña es incorrecta, devuelve un error de autorización
      if (!usuario) {
        return res.status(401).json({ error: 'Credenciales incorrectas' });
      }
  
      // Si el usuario existe y la contraseña es correcta, devuelve un mensaje de éxito
      res.status(200).json();
      res.redirect('./public/Dashboard.html')
    } catch (error) {
      // Si hay un error, devuelve un error de servidor interno
      res.status(500).json({ error: 'Error en el servidor' });
    }
  });
  




// Ruta para el dashboard (ver productos)
app.get('/public/Dashboard', async (req, res) => {
    try {
        // Obtener todos los productos de la base de datos
        const productos = await Producto.find();
        res.json(productos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});





// Ruta para filtrar productos
app.post('/public/filter', async (req, res) => {
    // Obtén los valores de los filtros del cuerpo de la solicitud
    const filters = req.body;

    try {
        // Extrae el año de la fecha de Baja si está presente
        if (filters.FechaBaja) {
            filters.FechaBaja = { $gte: new Date(filters.FechaBaja, 0, 1), $lt: new Date(parseInt(filters.FechaBaja) + 1, 0, 1) };
        }

        // Realiza la consulta a la base de datos utilizando los filtros recibidos
        const productos = await Producto.find(filters);
        res.json(productos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
    try {
        // Realiza la consulta a la base de datos utilizando los filtros recibidos
        const productos = await Producto.find({
            ...filters,
            // Filtro de rango de precios
            Precio: { $gte: filters.Precio.$gte, $lte: filters.Precio.$lte }
        });
        res.json(productos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});





// Ruta para añadir un producto
app.post('/public/Add', async (req, res) => {
    const { Tipologia, Subtipologia, Nombre, Descripcion, Ubicacion, FechaCompra, Seguro, FechaSeguro, Baja, FechaBaja, Responsable, Observaciones } = req.body;
    const producto = new Producto({ Tipologia, Subtipologia, Nombre, Descripcion, Ubicacion, FechaCompra, Seguro, FechaSeguro, Baja, FechaBaja, Responsable, Observaciones });

    try {
        const nuevoProducto = await producto.save();
        res.status(201).json(nuevoProducto);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});




const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor en ejecución en el puerto ${PORT}`);
});

