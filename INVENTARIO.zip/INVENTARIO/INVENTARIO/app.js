const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const { Double, Decimal128 } = require('mongodb');

const app = express();



// Conexión a la base de datos MongoDB
mongoose.connect('mongodb://localhost:27017/inventario')
    .then(() => console.log('Conexión a MongoDB establecida'))
    .catch(err => console.error('Error al conectar a MongoDB:', err));


// Servir archivos estáticos desde la carpeta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Ruta para cargar la página de inicio de sesión
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public','Login','src', 'Login.html'));
});





// Definir los esquemas de tus colecciones (usuarios y productos)
const usuarioSchema = new mongoose.Schema({
    correoUsuario: String,
    ContraseñaUsuario: String
});

const productoSchema = new mongoose.Schema({
Tipologia: String,
Subtipologia: String,
Nombre: String,
Descripcion: String,
Ubicacion: String,
Precio: Number,
FechaCompra: Date,
Baja: String,   
FechaBaja: Date,
Seguro: String,
FechaSeguro: Date,
Amortizacion: Number,
idContable: Number,
Observaciones: String
});

// Definir modelos basados en los esquemas
const Usuario = mongoose.model('Usuario', usuarioSchema);
const Producto = mongoose.model('Producto', productoSchema);



// Configurar middlewares
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());




// Rutas de tu aplicación
// Ruta para el login
app.post('/public/Login', async (req, res) => {
    const { correoUsuario, ContraseñaUsuario } = req.body;

    try {
        // Aquí deberías verificar las credenciales en tu base de datos
        // Por ejemplo, podrías buscar un usuario con el email dado y luego comparar las contraseñas
        const usuario = await Usuario.findOne({ correoUsuario });
        if (!usuario) {
            return res.status(404).json({ message: 'Usuario no encontrado' });
        }

        if (usuario.ContraseñaUsuario !== ContraseñaUsuario) {
            return res.status(401).json({ message: 'Contraseña incorrecta' });
        }

        // Aquí podrías generar un token de sesión y devolverlo en la respuesta si el login es exitoso
        // Por simplicidad, este ejemplo simplemente devuelve un mensaje de éxito
        res.json({ message: 'Inicio de sesión exitoso' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Ruta para el dashboard (ver productos)
// Ruta para el dashboard (ver productos)
app.get('/public/Dashboard', async (req, res) => {
    try {
        // Obtener todos los productos de la base de datos
        const productos = await Producto.find();
        res.json(productos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});



// Ruta para añadir un producto
app.post('/public/Add', async (req, res) => {
    const { Tipologia, Subtipologia, Nombre, Descripcion, Ubicacion, FechaCompra, Seguro, FechaSeguro, Baja, FechaBaja, Responsable, Observaciones } = req.body;
    const producto = new Producto({ Tipologia, Subtipologia, Nombre, Descripcion, Ubicacion, FechaCompra, Seguro, FechaSeguro, Baja, FechaBaja, Responsable, Observaciones });

    try {
        const nuevoProducto = await producto.save();
        res.status(201).json(nuevoProducto);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});




const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor en ejecución en el puerto ${PORT}`);
});

