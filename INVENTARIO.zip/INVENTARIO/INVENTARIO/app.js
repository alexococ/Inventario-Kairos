const express = require('express');
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static('public'));

const url = 'mongodb://localhost:27017';
const dbName = 'Inventario';
const usersCollection = 'Usuarios';
const productsCollection = 'Productos';

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public','Login', 'src','login.html'));
});

app.post('/Login', async (req, res) => {
    const { CorreoUsuario, ContraseñaUsuario } = req.body;

    const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(usersCollection);

        const user = await collection.findOne({ CorreoUsuario });

        if (user) {
            const isPasswordCorrect = await bcrypt.compare(ContraseñaUsuario, user.ContraseñaUsuario);
            if (isPasswordCorrect) {
                res.send('Inicio de sesión exitoso');
            } else {
                res.status(401).send('Credenciales incorrectas');
            }
        } else {
            res.status(401).send('Credenciales incorrectas');
        }
    } catch (error) {
        console.error('Error de inicio de sesión:', error);
        res.status(500).send('Error de servidor');
    } finally {
        await client.close();
    }
});

app.get('/Dashboard', async (req, res) => {
    const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(productsCollection);

        const products = await collection.find({}).toArray();

        res.json(products);
    } catch (error) {
        console.error('Error al obtener productos:', error);
        res.status(500).send('Error de servidor');
    } finally {
        await client.close();
    }
});

app.post('/Add', async (req, res) => {
    const { Tipologia, Subtipologia, Nombre, Descripcion, Ubicacion, Precio, FechaCompra, Baja, FechaBaja, Seguro, FechaSeguro, Amortizacion, idContable, Observaciones } = req.body;

    const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection(productsCollection);

        await collection.insertOne({ Tipologia, Subtipologia, Nombre, Descripcion, Ubicacion, Precio, FechaCompra, Baja, FechaBaja, Seguro, FechaSeguro, Amortizacion, idContable, Observaciones });
        res.send('Producto añadido correctamente');
    } catch (error) {
        console.error('Error al añadir producto:', error);
        res.status(500).send('Error de servidor');
    } finally {
        await client.close();
    }
});

app.listen(port, () => {
    console.log(`Servidor web escuchando en http://localhost:${port}`);
});
