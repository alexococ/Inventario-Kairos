const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'Inventario'
});

connection.connect((err) => {
  if (err) {
    console.error('Error de conexión:', err);
    return;
  }
  console.log('Conexión establecida correctamente');
});

// Ejemplo de consulta a la tabla Usuarios
connection.query('SELECT * FROM Usuarios', (err, rows) => {
  if (err) {
    console.error('Error al realizar la consulta:', err);
    return;
  }
  console.log('Usuarios:', rows);
});

// Ejemplo de inserción de datos en la tabla Productos
/*const nuevoProducto = {
  Tipologia: 'Algo',
  Subtipologia: 'Algo',
  Nombre: 'Nuevo Producto',
  Descripcion: 'Descripción del nuevo producto',
  Ubicacion: 'Almacén A',
  Precio: 50.00,
  FechaCompra: '2024-02-11',
  Baja: false,
  Seguro: true,
  Amortizacion: 10.00,
  idContable: 123,
  Observaciones: 'Ninguna'
};*/

connection.query('INSERT INTO Productos SET ?', nuevoProducto, (err, result) => {
  if (err) {
    console.error('Error al insertar nuevo producto:', err);
    return;
  }
  console.log('Nuevo producto insertado con éxito. ID:', result.insertId);
});

// Cerrar la conexión cuando haya terminado de realizar operaciones
connection.end();
