USE Inventario;

CREATE TABLE Usuarios (
idUsuario INT AUTO_INCREMENT PRIMARY KEY,
CorreoUsuario VARCHAR(255) NOT NULL,
ContraseñaUsuario VARCHAR(255) NOT NULL
);

CREATE TABLE Productos (
idProducto INT AUTO_INCREMENT PRIMARY KEY,
Tipologia VARCHAR(255),
Subtipologia VARCHAR(255),
Nombre VARCHAR(255),
Descripcion TEXT,
Ubicacion VARCHAR(255),
Precio DECIMAL(10, 2),
FechaCompra DATE,
Baja BOOLEAN,
FechaBaja DATE,
Seguro BOOLEAN,
FechaSeguro DATE,
Amortizacion DECIMAL(10, 2),
idContable INT,
Observaciones TEXT
);

-- Añadir el primer usuario
INSERT INTO Usuarios (CorreoUsuario, ContraseñaUsuario)
VALUES ('gcentro@kairos.coop', 'gcentro2024.');

-- Añadir el segundo usuario
INSERT INTO Usuarios (CorreoUsuario, ContraseñaUsuario)
VALUES ('rmarset@kairos.coop', 'rmarset2024.');
