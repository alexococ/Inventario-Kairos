1. Configuración de la base de datos:
Asegúrate de tener una base de datos MySQL configurada con una tabla que almacene la información de tu inventario, similar al paso 1 del ejemplo anterior.


2. Instalación de dependencias:
Asegúrate de tener Node.js y npm (o yarn) instalados en tu sistema. Luego, en el directorio de tu proyecto, ejecuta el siguiente comando para instalar las dependencias necesarias:


npm install express mysql


3. Conexión a la base de datos desde Node.js:
Crea un archivo db.js para manejar la conexión a la base de datos:

 JAVASCRIPT

const mysql = require('mysql');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'tu_usuario',
    password: 'tu_contraseña',
    database: 'nombre_de_tu_base_de_datos'
});

connection.connect((err) => {
    if (err) {
        console.error('Error de conexión a la base de datos: ' + err.stack);
        return;
    }
    console.log('Conexión a la base de datos establecida con el ID ' + connection.threadId);
});

module.exports = connection;


4. Operaciones CRUD:
Ahora, puedes crear rutas en tu aplicación Express para manejar las operaciones CRUD. Por ejemplo:

JAVASCRIPT

const express = require('express');
const router = express.Router();
const db = require('../db');

// Obtener todos los productos
router.get('/productos', (req, res) => {
    db.query('SELECT * FROM productos', (error, results) => {
        if (error) throw error;
        res.json(results);
    });
});

// Crear un nuevo producto
router.post('/productos', (req, res) => {
    const { nombre, descripcion, cantidad } = req.body;
    db.query('INSERT INTO productos (nombre, descripcion, cantidad) VALUES (?, ?, ?)', [nombre, descripcion, cantidad], (error, results) => {
        if (error) throw error;
        res.send('Producto añadido correctamente');
    });
});

// Actualizar un producto existente
router.put('/productos/:id', (req, res) => {
    const { nombre, descripcion, cantidad } = req.body;
    const { id } = req.params;
    db.query('UPDATE productos SET nombre = ?, descripcion = ?, cantidad = ? WHERE id = ?', [nombre, descripcion, cantidad, id], (error, results) => {
        if (error) throw error;
        res.send('Producto actualizado correctamente');
    });
});

// Eliminar un producto existente
router.delete('/productos/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM productos WHERE id = ?', [id], (error, results) => {
        if (error) throw error;
        res.send('Producto eliminado correctamente');
    });
});

module.exports = router;


5. Integración con Express.js:
Finalmente, integra estas rutas en tu aplicación Express principal:

JAVASCRIPT

const express = require('express');
const app = express();
const productosRoutes = require('./routes/productos');

app.use(express.json());
app.use('/api', productosRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor en ejecución en el puerto ${PORT}`));


6. Con esto, has configurado una API RESTful en Node.js y Express.js para manejar las operaciones CRUD en tu base de datos MySQL. Ahora puedes consumir estas rutas desde tu aplicación web utilizando AJAX u otras tecnologías frontend como React, Vue.js, o Angular.