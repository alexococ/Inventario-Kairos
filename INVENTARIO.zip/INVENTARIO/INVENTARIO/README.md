# README

use inventario

db.createCollection("usuarios")

db.createCollection("productos")

db.usuarios.insert({
"correoUsuario": "gcentro@kairos.coop",
"ContraseñaUsuario": "gcentro2024."
})

db.usuarios.insert({
"correoUsuario": "rmarset@kairos.coop",
"ContraseñaUsuario": "rmarset2024."
})
